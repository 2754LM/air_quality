# air_quality
项目架构

- backend存放后端文件，爬虫，fastapi处理在根目录。
- backend/data存放数据文件
- backend/data/raw存放原始数据文件
- backend/data/processed存放处理后的数据文件
- frontend存放前端文件

